import { TopStories } from './components';
import './App.css';

function App() {
  return (
    <div className="App" id="app">
      <TopStories />
    </div>
  );
}

export default App;
